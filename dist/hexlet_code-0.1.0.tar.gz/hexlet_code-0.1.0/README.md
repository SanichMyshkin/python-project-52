### Hexlet tests and linter status:
[![Actions Status](https://github.com/SanichMakakich/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/SanichMakakich/python-project-52/actions)

[![Deploy on Railway](https://railway.app/button.svg)](https://web-production-a9f18.up.railway.app/)